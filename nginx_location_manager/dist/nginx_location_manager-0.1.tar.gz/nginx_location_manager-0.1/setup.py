from setuptools import setup, find_packages

setup(
    name='nginx_location_manager',
    version='0.1',
    packages=find_packages(),
    entry_points={},
    install_requires=[],
)